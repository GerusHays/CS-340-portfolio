from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelter:
    """CRUD operations for the Austin Animal Center MongoDB collection."""

    def __init__(self, username="aacuser", password="L",
                 host="localhost", port=27017,
                 db_name="aac", collection_name="animals"):
        """
        Initialize the MongoDB client, database, and collection.
        """
        self.username = username
        self.password = password
        self.host = host
        self.port = port
        self.db_name = db_name
        self.collection_name = collection_name

        try:
            self.client = MongoClient(
                f"mongodb://{self.username}:{self.password}@{self.host}:{self.port}/?authSource=admin"
            )
            self.database = self.client[self.db_name]
            self.collection = self.database[self.collection_name]
        except PyMongoError as error:
            print(f"Database connection error: {error}")
            raise

    def create(self, data):
        """
        Insert a document into the MongoDB collection.
        """
        if data is None:
            return False

        try:
            self.collection.insert_one(data)
            return True
        except PyMongoError as error:
            print(f"Create error: {error}")
            return False

    def read(self, query):
        """
        Query documents from the MongoDB collection.
        """
        if query is None:
            return []

        try:
            result = self.collection.find(query)
            return list(result)
        except PyMongoError as error:
            print(f"Read error: {error}")
            return []

    def update(self, query, new_values):
        """
        Update document(s) in the MongoDB collection.
        """
        if query is None or new_values is None:
            return 0

        try:
            result = self.collection.update_many(query, new_values)
            return result.modified_count
        except PyMongoError as error:
            print(f"Update error: {error}")
            return 0

    def delete(self, query):
        """
        Delete document(s) from the MongoDB collection.
        """
        if query is None:
            return 0

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError as error:
            print(f"Delete error: {error}")
            return 0